let campo1 = document.querySelector("#campo1");
let campo2 = document.querySelector("#campo2");
let btSomar = document.querySelector("#btSomar");
let h3Resultado = document.querySelector("#h3Resultado");

function  somarNumeros(){

    let num1 = Number(campo1.value);
    let num2 = Number(campo2.value);

    h3Resultado.textContent = (num1 - num2);
}

btSomar.onclick = function(){
    somarNumeros();
    
}