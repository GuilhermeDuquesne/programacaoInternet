let Numero1 = document.querySelector("#Numero1");
let Numer02 = document.querySelector("#Numero");
let btmaior = document.querySelector("#btmaior");
let h3resultado = document.querySelector("#h3resultado");

function maior (){

    let num1 = Number(Numero1.value);
    let num2 = Number(Numero.value);
    let media = (num1 + num2) / 2;

    //Aprovado: média 6.0 ou maior
    //Reprovado: média menor que 6.0
    
    if(media >= 6.0){
        h3resultado.textContent = "Parabens você está aprovado!!!"
    }else{
        h3resultado.textContent = "Não desista, tente novamente;-;"
    }

    
}

btmaior.onclick = function() {
    maior();
}

 