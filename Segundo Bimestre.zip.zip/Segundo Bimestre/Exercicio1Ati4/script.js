let input1 = document.querySelector("#input1");
let input2 = document.querySelector("#input2");
let input3 = document.querySelector("#input3");
let imprimir = document.querySelector("#imprimir");
let resultado = document.querySelector("#resultado");
let resultado2 = document.querySelector("#resultado2");
let resultado3 = document.querySelector("#resultado3");
let resultado4 = document.querySelector("#resultado4");

function mediaaritmetica(){

     let num1 = Number (input1.value);
     let num2 = Number (input2.value);
     let num3 = Number (input3.value);

     resultado.textContent = (num1+  num2 + num3) /3;
     resultado2.textContent = ((3*num1) + (2*num2) + (5*num3))/(3+2+5);
     resultado3.textContent = ((num1+  num2 + num3) /3) + ((3*num1) + (2*num2) + (5*num3))/(3+2+5);
     resultado4.textContent = (((num1+  num2 + num3) /3) + ((3*num1) + (2*num2) + (5*num3))/(3+2+5)) /2;
    
}

imprimir.onclick = function (){
    mediaaritmetica();
}
