let pontoX1 = document.querySelector("#pontoX1");
let pontoY1 = document.querySelector("#pontoY1");
let pontoX2 = document.querySelector("#pontoX2");
let pontoY2 = document.querySelector("#pontoY2");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");

function inferno(){
    let ponto1x = Number(pontoX1.value);
    let ponto1y = Number(pontoY1.value);
    let ponto2x = Number(pontoX2.value);
    let ponto2y = Number(pontoY2.value);

    let resl1 = (ponto1x - ponto2x)
    let resl2 = (ponto1y - ponto2y)

    let resl3 = (resl1**2)
    let resl4 = (resl2**2)

    let resl5 = resl4 + resl3

    let resultadofinal = Math.sqrt(resl5)



    resultado.textContent = resultadofinal
}
btcalcular.onclick = function(){
    inferno();
}