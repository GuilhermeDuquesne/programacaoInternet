let cavalos = document.querySelector("#cavalos");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");

function ferraduras(){

    let num1 = Number (cavalos.value);

    resultado.textContent = (num1 * 4);
}

btcalcular.onclick = function(){
    ferraduras();
}