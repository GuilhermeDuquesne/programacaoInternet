let input = document.querySelector("#input");
let Éimpar = document.querySelector("#Éimpar");
let resultado = document.querySelector("#resultado");


function imparoupar(){

let num1 = Number (input.value)

if(num1%2 == 0){
    resultado.textContent = "Não"
}else{
    resultado.textContent = "Sim"
}

}

Éimpar.onclick = function(){
    imparoupar();
}