let camisaP = document.querySelector("#camisaP");
let camisaM = document.querySelector("#camisaM");
let camisaG = document.querySelector("#camisaG");
let btPreço = document.querySelector("#btPreço");
let resultado = document.querySelector("#resultado");

function Valores(){

    let CP = Number(camisaP.value);
    let CM = Number(camisaM.value);
    let CG = Number(camisaG.value);

    let preçoP = CP * 10
    let preçoM = CM * 12
    let preçoG = CG * 15

    resultado.textContent = preçoP + preçoM + preçoG
}

btPreço.onclick = function(){
    Valores();
}