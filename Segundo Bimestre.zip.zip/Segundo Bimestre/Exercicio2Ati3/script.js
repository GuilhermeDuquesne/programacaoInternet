let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let btresultados = document.querySelector("#btresultados");
let resultadosoma = document.querySelector("#resultadosoma");
let resultadosubtração = document.querySelector("#resultadosubtração");
let resultadomultiplicação = document.querySelector("#resultadomultiplicação");
let resultadodivisão = document.querySelector("#resultadodivisão");

function calcular(){

    let num1 = Number(numero1.value);
    let num2 = Number(numero2.value);

    resultadosoma.textContent = (num1 + num2);
    resultadosubtração.textContent = (num1 - num2);
    resultadomultiplicação.textContent = (num1 * num2);
    resultadodivisão.textContent = (num1 / num2);
}

btresultados.onclick = function(){
    calcular();
}