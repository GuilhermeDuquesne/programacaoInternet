let input1 = document.querySelector("#input1");
let input2 = document.querySelector("#input2");
let input3 = document.querySelector("#input3");
let imprimir = document.querySelector("#imprimir");
let resultado = document.querySelector("#resultado");

function mediaaritmetica(){

     let num1 = Number (input1.value);
     let num2 = Number (input2.value);
     let num3 = Number (input3.value);

     //média aritimedica
     let Mediaari = (num1+  num2 + num3) /3;


     //média ponderada
     let somadovalores = (3*num1) + (2*num2) + (5*num3);
     let somadospesos = 3+2+5;
     let Ponderada = somadovalores / somadospesos;

     //soma das médias
     let somaMedias = Ponderada + Mediaari;

     //mediadasmédias
     let mediadasmedias = somaMedias/2;

     resultado.innerHTML = "Media Aritimetica: " +
      Mediaari+"<br>"+"Media ponderada: " +
      Ponderada+"<br>"+"Soma das Medias: " +
      somaMedias+"<br>"+"Media das Medias"+mediadasmedias;
    
}

imprimir.onclick = function (){
    mediaaritmetica();
}