let dimensão1 = document.querySelector("#dimensão1");
let dimensão2 = document.querySelector("#dimensão2");
let btÁrea = document.querySelector("#btÁrea");
let resultado = document.querySelector("#resultado");

function dimenções (){

    let num1 = Number (dimensão1.value);
    let num2 = Number (dimensão2.value);

    resultado.textContent = "Área do Terreno: " + (num1 * num2);
}

btÁrea.onclick = function(){
    dimenções();
}