let Numero1 = document.querySelector("#Numero1");
let Numer02 = document.querySelector("#Numero");
let btmaior = document.querySelector("#btmaior");
let h3resultado = document.querySelector("#h3resultado");

function maior (){

    let num1 = Number(Numero1.value);
    let num2 = Number(Numero.value);

    //maior numero
    
    if(num1 > num2){
        h3resultado.textContent = num1
    }else{
        h3resultado.textContent = num2
    }

    
}

btmaior.onclick = function() {
    maior();
}