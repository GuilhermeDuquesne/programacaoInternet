//Três amigos, Carlos, André e Felipe, decidiram rachar igualmente a conta de um bar.
//Faça uma página para ler o valor total da conta e imprimir quanto cada um deve pagar,
//mas faça com que Carlos e André não paguem centavos. Ex.: uma conta de R$101,53
//resulta em R$33,00 para Carlos, R$33,00 para André e R$35,53 para Felipe.

let input = document.querySelector("#input");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");

function conta(){

    let num1 = Number(input.value)

    let André = Math.floor(num1 / 3)
    let Carlos = Math.floor(num1 / 3)

    let dividindo = num1/3
    let resto = dividindo * 2
    let Felipe = (resto % 2) + num1 / 3

    resultado.textContent = "André pagará: R$" + André + " Carlos pagará: R$" + Carlos + " Felipe pagará: R$" + Felipe;
}

btcalcular.onclick = function(){
    conta();
}