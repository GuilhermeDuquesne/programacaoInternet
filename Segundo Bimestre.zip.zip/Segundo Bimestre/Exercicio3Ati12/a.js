let input = document.querySelector("#input");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");

function algoritimo(){

    let input1 = Number(input.value)

    let centena = Math.floor(input1 / 100)
    let resto = input1 % 100

    let dezenas = Math.floor(resto / 9);
    let numerosrestantes = resto % 9;

    resultado.textContent = "centenas " + centena + " dezenas: "+ dezenas + " unidades: " + numerosrestantes;
}
btcalcular.onclick = function(){
    algoritimo();
}