let numrecebido = document.querySelector("#numrecebido");
let btcalcular = document.querySelector("#btcalcular");
let resultado1 = document.querySelector("#resultado1");
let resultado2 = document.querySelector("#resultado2");
let resultado3 = document.querySelector("#resultado3");
let resultado4 = document.querySelector("#resultado4");

function cotacaoatual(){

    let num1 = Number(numrecebido.value);

    resultado1.textContent = (num1 * 1.01);
    resultado2.textContent = (num1 * 1.02);
    resultado3.textContent = (num1 * 1.05);
    resultado4.textContent = (num1 * 1.10);
}

btcalcular.onclick = function(){
    cotacaoatual();
}