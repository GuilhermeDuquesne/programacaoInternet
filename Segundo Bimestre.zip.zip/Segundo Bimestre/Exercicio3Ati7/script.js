let mês = document.querySelector("#mês");
let dia = document.querySelector("#dia");
let btdias = document.querySelector("#btdias");
let resultado = document.querySelector("#resultado");

function diasdoano(){
     let datadia = Number (dia.value);
     let datamês = Number (mês.value);

     let x30 = (datamês * 30) - 30 

     if(datamês = 1){
           resultado.textContent = "já se passaram "+datadia+" dias do ano.";
     }
     if(datamês>1);{
        resultado.textContent = "já se passaram "+(datadia + x30) +" dias do ano.";
     }
}

btdias.onclick = function(){
    diasdoano();
}