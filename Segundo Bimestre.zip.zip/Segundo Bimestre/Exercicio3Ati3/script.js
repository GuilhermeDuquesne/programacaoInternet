let Pães = document.querySelector("#Pães");
let Broas = document.querySelector("#Broas");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function Contas(){

    let pao = Number(Pães.value);
    let broa = Number(Broas.value);

    let contpao = pao * 0.12
    let contbroa = broa * 1.50

    let soma = contbroa + contpao
    let porcentagem = soma / 10

    resultado.textContent = soma + "  Guarde:  " + porcentagem

}

btCalcular.onclick = function(){
    Contas();
}