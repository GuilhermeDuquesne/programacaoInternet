//Calcule a área de uma pizza que possui um raio R (pi=3.14).

let input = document.querySelector("#input");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");

function raio(){

    let num1 = Number(input.value)

    let formula1 = num1**2
    let formula2 = 3.14 * formula1

    resultado.textContent = formula2+"²cm"
}

btcalcular.onclick = function(){
    raio();
}