let Valordoquilo = document.querySelector("#Valordoquilo");
let QuantiaDeKgConsumido = document.querySelector("#QuantiaDeKgConsumido");
let btSomar = document.querySelector("#btSomar");
let h3Resultado = document.querySelector("#h3Resultado");

function  somarNumeros(){

    let num1 = Number(Valordoquilo.value);
    let num2 = Number(QuantiaDeKgConsumido.value);

    h3Resultado.textContent = (num1 * num2);
}

btSomar.onclick = function(){
    somarNumeros();
    
}