//Uma fábrica controla o tempo de trabalho sem acidentes pela quantidade de dias. Faça
//uma página para converter este tempo em anos, meses e dias. Considere que cada mês
//possui sempre 30 dias.
let dias = document.querySelector("#dias");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");

function Dias_Sem_Acidentes() {
    let totalDias = Number(dias.value);

    let anos = Math.floor(totalDias / 365);
    let resto = totalDias % 365;

    let meses = Math.floor(resto / 30);
    let diasRestantes = resto % 30;

    resultado.textContent =  anos + "anos " + meses + "meses "+ diasRestantes + " dias sem acidentes.";
}

btcalcular.onclick = function() {
    Dias_Sem_Acidentes();
};