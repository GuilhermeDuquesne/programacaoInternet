let kilos = document.querySelector("#kilos");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");

function kilosf(){

    let num1 = Number (kilos.value);

    resultado.textContent = (num1 * 12) + "R$"
}

btcalcular.onclick = function(){
    kilosf();
}