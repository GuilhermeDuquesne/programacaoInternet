//Faça uma página para ler o salário de um funcionário e aumentá-lo em 15%. Após o
//aumento, desconte 8% de impostos. Imprima o salário inicial, o salário com o aumento
//e o salário final.

let input = document.querySelector("#input");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");


function salarios(){

    let salario = Number(input.value);

    let salarioaumentosoma = salario * 0.15
    let salarioaumento = Math.floor(salarioaumentosoma + salario)

    let salarioimposto = Math.floor(salarioaumento * 0.8)

resultado.textContent = "Salário inicial R$" + salario + ". Salário com aumento R$" + salarioaumento + ". Salário com imposto R$" + salarioimposto + "."

}

btcalcular.onclick = function(){
    salarios();
}