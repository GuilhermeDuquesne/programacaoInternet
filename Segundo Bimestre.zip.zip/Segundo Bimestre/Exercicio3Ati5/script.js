//Um motorista deseja colocar no seu tanque X reais de gasolina. Desenvolva uma
//página para ler o preço do litro da gasolina e o valor do pagamento, e exibir quantos
//litros ele conseguiu colocar no tanque.

let reais = document.querySelector("#reais");
let litros = document.querySelector("#litros");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");


function gasulina(){

    let num1 = Number (reais.value);
    let num2 = Number (litros.value);



    resultado.textContent = "Você consegue colocar: " + (num1 / num2)+" Litros" 
}

btCalcular.onclick = function(){
    gasulina();
}
