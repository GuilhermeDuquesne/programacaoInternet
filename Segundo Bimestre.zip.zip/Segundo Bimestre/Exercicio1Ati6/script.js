let Numero1 = document.querySelector("#Numero1");
let Numero2 = document.querySelector("#Numero2");
let Numero3 = document.querySelector("#Numero3");
let Numero4 = document.querySelector("#Numero4");
let btmenor = document.querySelector("#btmenor");
let resultados = document.querySelector("#resultados");

function QualMenor(){

    let num1 = Number(Numero1.value);
    let num2 = Number(Numero2.value);
    let num3 = Number(Numero3.value);
    let num4 = Number(Numero4.value);


    let menor = num1;

    if (num2 < menor) {
        menor = num2;
    }
    
    if (num3 < menor) {
        menor = num3;
    }

    if (num4 < menor) {
        menor = num4;
    }

    resultados.textContent = menor;


}

btmenor.onclick = function(){
    QualMenor();
}