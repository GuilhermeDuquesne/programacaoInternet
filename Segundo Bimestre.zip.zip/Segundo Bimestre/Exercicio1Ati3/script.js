let Saldo = document.querySelector("#Saldo");
let Reajuste = document.querySelector("#Reajuste");
let Resultado = document.querySelector("#Resultado");

function reajuste1 (){

    let num1 = Number (Saldo.value);

    Resultado.textContent = (num1 * 1.01);

}
  
Reajuste.onclick = function(){
    reajuste1();
}

