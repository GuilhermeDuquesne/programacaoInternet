let nome = document.querySelector("#nome");
let idade = document.querySelector("#idade");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function calcular(){

    let nomes = (nome.value);
    let num1 = Number(idade.value);

    let dias = num1 * 365 + " dias de vida!!"
    let nomee = nomes + " você tem "

    resultado.textContent = nomee + dias

}

btCalcular.onclick = function(){
    calcular();
}