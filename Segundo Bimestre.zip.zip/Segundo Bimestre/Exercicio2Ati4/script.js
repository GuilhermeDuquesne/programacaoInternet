let sabor1 = document.querySelector("#sabor1");
let sabor2 = document.querySelector("#sabor2");
let sabor3 = document.querySelector("#sabor3");
let sabor4 = document.querySelector("#sabor4");
let refrigerantes = document.querySelector("#refrigerantes");
let btconta = document.querySelector("#btconta");
let resultadosabores = document.querySelector("#resultadosabores");
let resultadovalor = document.querySelector("#resultadovalor");



function pizzas(){

    let text1 = sabor1.value;
    let text2 = sabor2.value;
    let text3 = sabor3.value;
    let text4 = sabor4.value;

    let num1 = Number (refrigerantes.value);

    let sabor11 = 12
    let sabor22 = 24
    let sabor33 = 36
    let sabor44 = 48
    
    
    if(text1 !== ""){
        resultadovalor.textContent = sabor11 + (num1 * 7);
        resultadosabores.textContent = (text1)+".";
    }if(text2 !== ""){
        resultadovalor.textContent = sabor22 + (num1 * 7);
        resultadosabores.textContent = (text1) + ", " + (text2)+".";
    }if(text3 !== ""){
        resultadovalor.textContent = sabor33 + (num1 * 7);
        resultadosabores.textContent = (text1) + ", " + (text2) + ", " +  (text3)+".";
    }if(text4 !== ""){
        resultadovalor.textContent = sabor44 + (num1 * 7);
        resultadosabores.textContent = (text1) + ", " + (text2) + ", " +  (text3) + ", " +  (text4)+".";
    }



}


btconta.onclick = function(){
    pizzas();
}