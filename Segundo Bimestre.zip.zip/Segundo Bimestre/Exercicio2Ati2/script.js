let omeletes = document.querySelector("#omeletes");
let btcalcular = document.querySelector("#btcalcular");
let resultadoovos = document.querySelector("#resultadoovos");
let resultadoqueijo = document.querySelector("#resultadoqueijo");


function omelete(){

    let num1 = Number(omeletes.value);

    resultadoovos.textContent = (num1 * 2);
    resultadoqueijo.textContent = (num1 * 50);

}

btcalcular.onclick = function(){
    omelete();
}