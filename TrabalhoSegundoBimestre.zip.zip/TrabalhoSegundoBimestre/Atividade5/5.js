/*Calculadora de Crédito Bancário: Um banco concederáum crédito especial aos seus
clientes, variável com o saldo médio no último ano. Faça uma página que leia o saldo
médio de um cliente e calcule o valor do crédito de acordo com a tabela abaixo.
Mostre uma mensagem informando o saldo médio e o valor do crédito.*/

let saldomedio = document.querySelector("#saldomedio");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");

function CéditoBancario(){

    let num1 = Number(saldomedio.value)

    let vinte = Math.floor(num1 * 0.20)

    let trinta = Math.floor(num1 * 0.30)

    let quarenta = Math.floor(num1 * 0.40)

    if(num1 < 201){
        resultado.textContent = "Nenhum Crédito"
    }
    if(num1 > 200 && num1 <401){
        resultado.textContent = "Saldo Médio R$" + num1 + " Valor do Crédito R$" + vinte 
    }
    if(num1 > 400 && num1 <601){
        resultado.textContent = "Saldo Médio R$" + num1 + " Valor do Crédito R$" + trinta 
    }
    if(num1 > 600){
        resultado.textContent = "Saldo Médio R$" + num1 + " Valor do Crédito R$" + quarenta 
    }
}

btcalcular.onclick = function(){
    CéditoBancario();
}

let btvoltar = document.getElementById('btvoltar');

    btvoltar.addEventListener('click', () => {
      window.location.href = "../PáginaInicial.html";
    });