//1. Encontre o triângulo: Dados três valores X, Y e Z, verificar se eles podem ser os
//comprimentos dos lados de um triângulo e, se forem verificar se éum triângulo
//equilátero, isósceles ou escalenos. Se eles não formarem um triângulo, escrever a
//mensagem. Considere as seguintes propriedades:
//● O comprimento de cada lado em um triângulo émenor que a soma dos outros
//dois lados;
//● Equiláteros: tem os comprimentos dos três lados iguais;
//● Isósceles: tem os comprimentos de dois lados iguais;
//● Escaleno: tem os comprimentos de três lados diferentes.

let inputX = document.querySelector("#inputX");
let inputY = document.querySelector("#inputY");
let inputZ = document.querySelector("#inputZ");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado")

function IStriangolo(){

    let ladoX = Number(inputX.value);
    let ladoY = Number(inputY.value);
    let ladoZ = Number(inputZ.value);

    let somaXY = ladoX + ladoY;
    let somaXZ = ladoX + ladoZ;
    let somaYZ = ladoY + ladoZ;

if(ladoZ < somaXY && ladoX < somaYZ && ladoY < somaXZ){
    if(ladoX === ladoY && ladoY === ladoZ && ladoX === ladoZ){
        resultado.textContent = "Equilátero.";
    }
    else if(ladoX === ladoY || ladoY === ladoZ || ladoX === ladoZ){
        resultado.textContent = "Isoceles.";
    }else {
        resultado.textContent = "Escaleno."
    }
}else{
    resultado.textContent = "Não é um triângulo."
}

}

btcalcular.onclick = function(){
    IStriangolo();
}

const btvoltar = document.getElementById('btvoltar');

    btvoltar.addEventListener('click', () => {
      window.location.href = "../PáginaInicial.html";
    });