/*Calculadora de Impostos: Num determinado Estado, para transferências de veículos, o
DETRAN cobra uma taxa de 1% para carros fabricados antes de 1990 e uma taxa de
1.5% para os fabricados de 1990 em diante, a taxa incide sobre o valor de tabela do
carro. Elabore uma página que leia o ano e o valor de tabela do carro, calcule e informe
o imposto a ser pago.*/

let valor = document.querySelector("#valor");
let imposto = document.querySelector("#imposto");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");

function DETRAN(){

    let num1 = Number(valor.value)
    let num2 = Number(imposto.value)

    if(num2>=1990){
        resultado.innerHTML = "<br>Você deve pagar: " + num1 * 0.015 + " de impostos."
    }else{ 
        resultado.innerHTML = "<br>Você deve pagar: " + num1 * 0.01 + " de impostos."
    }
}

btcalcular.onclick = function(){
    DETRAN();
}

let btvoltar = document.getElementById('btvoltar');

    btvoltar.addEventListener('click', () => {
      window.location.href = "../PáginaInicial.html";
    });