let btA1js = document.getElementById('btA1js');

    btA1js.addEventListener('click', () => {
      window.location.href = "Atividade1/1.html";
    });

let btA2js = document.getElementById('btA2js');

    btA2js.addEventListener('click', () => {
      window.location.href = "Atividade2/2.html";
    });

let btA3js = document.getElementById('btA3js');

    btA3js.addEventListener('click', () => {
      window.location.href = "Atividade3/3.html";
    });

let btA4js = document.getElementById('btA4js');

    btA4js.addEventListener('click', () => {
      window.location.href = "Atividade4/4.html";
    });
let btA5js = document.getElementById('btA5js');

    btA5js.addEventListener('click', () => {
      window.location.href = "Atividade5/5.html";
    });

let btA6js = document.getElementById('btA6js');

    btA6js.addEventListener('click', () => {
      window.location.href = "Atividade6/6.html";
    });

let btA7js = document.getElementById('btA7js');

    btA7js.addEventListener('click', () => {
      window.location.href = "Atividade7/7.html";
    });

let btA8js = document.getElementById('btA8js');

    btA8js.addEventListener('click', () => {
      window.location.href = "Atividade8/8.html";
    });
