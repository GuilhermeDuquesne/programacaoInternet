/*Sistema de Vendas: Elabore uma página que calcule o que deve ser pago por um
produto, considerando o preço normal de etiqueta e a escolha da condição de
pagamento. Utilize os códigos da tabela a seguir para ler qual a condição de
pagamento escolhida e efetuar o cálculo adequado.
Código Condição de pagamento
a) Àvista em dinheiro ou cheque, recebe 10% de desconto
b) Àvista no cartão de crédito, recebe 15% de desconto
c) Em duas vezes, preço normal de etiqueta sem juros
d) Em duas vezes, preço normal de etiqueta mais juros de 10%*/

let preço = document.querySelector("#preço");
let btdinheiro = document.querySelector("#btdinheiro");
let btcartão = document.querySelector("#btcartão");
let btsemjuros = document.querySelector("#btsemjuros");
let btjuros = document.querySelector("#btjuros");
let resultado = document.querySelector("#resultado");

function loja(processo){

    let num1 = Number(preço.value)

    if( processo === "dinheiro" ){
        let calculo = num1 * 0.10
        resultado.textContent = "R$" + (num1 + calculo)
    }
    if(processo === "cartão"){
        let calculo = num1 * 0.15
        resultado.textContent = "R$" + (num1 + calculo)
    }
    if(processo === "semjuros"){
        resultado.textContent = "Duas vezes de R$" + (num1 / 2) + " sem juros."
    }
    if(processo === "juros"){
        let calculo = num1 * 0.10
        resultado.textContent = "Duas vezes de R$" + (num1 + calculo)/2
    }
}

btdinheiro.onclick = function(){
    loja("dinheiro");
}

btcartão.onclick = function(){
    loja("cartão");
}

btsemjuros.onclick = function(){
    loja("semjuros");
}

btjuros.onclick = function(){
    loja("juros");
}

let btvoltar = document.getElementById('btvoltar');

    btvoltar.addEventListener('click', () => {
      window.location.href = "../PáginaInicial.html";
    });