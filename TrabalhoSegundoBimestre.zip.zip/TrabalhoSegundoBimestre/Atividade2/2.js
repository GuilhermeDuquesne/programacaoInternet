/*Calculadora IMC: Faça uma página para inserir o peso (kg) e altura (m), e o programa
calcula o IMC e informa a classificação.
Entradas:
● Campo para peso.
● Campo para altura.
Saída esperada:
● Exibe o valor do IMC.
● Mostra a classificação:
○ Abaixo de 18.5 → Abaixo do peso
○ 18.5 a 24.9 → Peso normal
○ 25 a 29.9 → Sobrepeso
○ 30 a 34.9 → Obesidade grau 1
○ 35 a 39.9 → Obesidade grau 2
○ 40+ → Obesidade grau 3.*/

let peso = document.querySelector("#peso");
let altura = document.querySelector("#altura");
let btcalcular = document.querySelector("#btcalcular")
let resultado = document.querySelector("#resultado");


function IMC(){
 
    let peso1 = Number(peso.value);
    let altura1 = Number(altura.value);

    let alturaX = altura1 * altura1

    let resultadoIMC = peso1 / alturaX

    if(resultadoIMC < 18.5){
        resultado.textContent = "Abaixo do peso"
    }
    if(resultadoIMC >= 18.5 && resultadoIMC < 24.9){
        resultado.textContent = "Peso normal"
    }
    if(resultadoIMC >= 25 && resultadoIMC < 29.9){
        resultado.textContent = "Sobrepeso"
    }
    if(resultadoIMC >= 30 && resultadoIMC < 34.9){
        resultado.textContent = "Obesidade grau 1"
    }
    if(resultadoIMC >= 35 && resultadoIMC < 39.9){
        resultado.textContent = "Obesidade grau 2"
    }
    if(resultadoIMC > 40){
        resultado.textContent = "Obesidade grau 3"
    }


}

btcalcular.onclick = function(){
    IMC();
}

let btvoltar = document.getElementById('btvoltar');

    btvoltar.addEventListener('click', () => {
      window.location.href = "../PáginaInicial.html";
    });