/* Calculadora de salário: Uma empresa concederáum aumento de salário aos seus
funcionários variável de acordo com o cargo, conforme a tabela abaixo. Faça uma
página que leia o salário e o cargo de um funcionário e calcule o novo salário. Se o
cargo do funcionário não estiver na tabela, ele deverá, então, receber 40% de
aumento. Mostre o salário antigo, o novo salário e a diferença.*/

let salario = document.querySelector("#salario");
let Cargo = document.querySelector("#Cargo");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");


function Aumentos(){

    let num1 = Number(salario.value);
    let text1 = Cargo.value;

    let GerenteAumento = num1 * 0.10
    let EngenheiroAumento = num1 * 0.20
    let TécnicoAumento = num1 * 0.30
    let OutrosAumento = num1 * 0.40

    if(text1 == "Gerente"|| text1 == "gerente"||text1 == "GERENTE"){
        resultado.textContent = "Salário Inicial: R$" + num1 + " Novo Salário: R$" + (num1 + GerenteAumento) + " Diferença: R$" + GerenteAumento
    }
    else if(text1 == "Engenheiro"||text1 ==  "engenheiro"||text1 == "ENGENHEIRO"){
        resultado.textContent = "Salário Inicial: R$" + num1 + " Novo Salário: R$" + (num1 + EngenheiroAumento) + " Diferença: R$" + EngenheiroAumento
    }
    else if(text1 == "Técnico"||text1 == "TÉCNICO"||text1 == "técnico"||text1 == "Tecnico"||text1=="tecnico"||text1=="TECNICO"){
        resultado.textContent = "Salário Inicial: R$" + num1 + " Novo Salário: R$" + (num1 + TécnicoAumento) + " Diferença: R$" + TécnicoAumento
    }
    else{
        resultado.textContent = "Salário Inicial: R$" + num1 + " Novo Salário: R$" + (num1 + OutrosAumento) + " Diferença: R$" + OutrosAumento
    }


}

btcalcular.onclick = function(){
    Aumentos();
};

let btvoltar = document.getElementById('btvoltar');

    btvoltar.addEventListener('click', () => {
      window.location.href = "../PáginaInicial.html";
    });