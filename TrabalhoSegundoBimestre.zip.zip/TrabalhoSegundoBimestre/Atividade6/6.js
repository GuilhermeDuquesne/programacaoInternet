let code = document.querySelector("#code");
let qntd = document.querySelector("#qntd");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#resultado");

function lanchonete(){

    let codigo = Number (code.value);
    let quantia = Number (qntd.value);

    let CachorroQuente = 12
    let Bauru = 8.50
    let MistoQuente = 8
    let Hamburguer = 9
    let Cheesburguer = 10
    let Refrigerante = 4.50

    if(codigo == 143){
        resultado.textContent = "Valor a ser pago R$" + (CachorroQuente * quantia)
    }
    if(codigo == 132){
        resultado.textContent = "Valor a ser pago R$" + (Bauru * quantia)
    }
    if(codigo == 354){
        resultado.textContent = "Valor a ser pago R$" + (MistoQuente * quantia)
    }
    if(codigo == 213){
        resultado.textContent = "Valor a ser pago R$" + (Hamburguer * quantia)
    }
    if(codigo == 832){
        resultado.textContent = "Valor a ser pago R$" + (Cheesburguer * quantia)
    }
    if(codigo == 328){
        resultado.textContent = "Valor a ser pago R$" + (Refrigerante * quantia)
    }
}

btcalcular.onclick = function(){
    lanchonete();
}
let btvoltar = document.getElementById('btvoltar');

    btvoltar.addEventListener('click', () => {
      window.location.href = "../PáginaInicial.html";
    });
